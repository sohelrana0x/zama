# Executor

The Executor service is a gRPC server that accepts FHE computation requests from the full node/validator node and executes them.

## Build

```bash
cargo build -r
```
