# fhEVM API specifications
