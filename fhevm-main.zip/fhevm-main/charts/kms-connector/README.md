# Zama KMS Connector Helm Chart

A helm chart to distribute and deploy the [KMS Connector](https://github.com/zama-ai/kms-connector/).


    helm registry login ghcr.io/zama-ai/helm-charts
    helm install kms-connector oci://ghcr.io/zama-ai/helm-charts/kms-connector
