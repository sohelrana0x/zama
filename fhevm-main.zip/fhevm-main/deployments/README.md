# Helm Charts Deployment

## Requirements

Install the following tools

* Helm: https://helm.sh/docs/intro/install/ and the helm-diff plugin (https://github.com/databus23/helm-diff?tab=readme-ov-file#install)
* Helmfile: https://helmfile.readthedocs.io/en/latest/#installation

    helmfile -f fhevm/helmfile.yaml apply
